/*
DBS211 - Project Final Submission
Section: ZEE
Group Nmuber:2
Member Names:       | Student ID's
1. Disha Rawat      | 145286209
2. Harpreet Singh   | 155912207
3. Pavneet Kaur     | 128287216
4. Rahul Raj        | 134529213
5. Tanish           | 143461200
*/
#define _CRT_SECURE_NO_WARNINGS
//  Required libraries
#include <iostream>
#include <iomanip>
#include <occi.h>
#include <cctype>
//  Oracle classes 
using oracle::occi::Environment;
using oracle::occi::Connection;
//  Oracle namespaces and standard C++
using namespace oracle::occi;
using namespace std;
// EMPLOYEE STRUCT
struct Employee {
	int employeeNumber;
	char lastName[50];
	char firstName[50];
	char email[100];
	char phone[50];
	char extension[10];
	char officecode[10];
	char reportsTo[100];
	char jobTitle[50];
	char city[50];
};
// FUNCTION PROTOTYPES
// Menu for  selection
int menu(void);
// For finding employee using employee number
int findEmployee(Connection* conn, int employeeNumber, struct Employee* emp);
// For displaying single employee information found from the findEmployee function.
void displayEmployee(Connection* conn, struct Employee emp);
//For displaying all employees' connected to information with manager name
void displayAllEmployees(Connection* conn);
//For getting value of employeeNumber
int getInt(const char* prompt);
//for prompting user to enter information about new employee to be added
void getEmployee(Employee* emp);
//for adding new employee to table
void insertEmployee(Connection* conn, struct Employee emp);
//for deleting employee from table
void deleteEmployee(Connection* conn, int employeeNumber);
//for updating extension of an employee
void updateEmployee(Connection* conn, int employeeNumber);
// Execution Starts from here
int main(void)
{
	// OCCI Variables
	Environment* env = nullptr;
	Connection* conn = nullptr;
	// User Variables
	string usr = "dbs211_221k13";
	string pass = "12694242";
	string srv = "myoracle12c.senecacollege.ca:1521/oracle12c";
	// Try connection to DataBase and catch Exception if there's a failure
	try
	{
		//  Oracle environment and connection
		env = Environment::createEnvironment(Environment::DEFAULT);
		conn = env->createConnection(usr, pass, srv);

		int selection = -1, employeeNum;
		bool isQuit = false;
		Employee employee = {};

		do
		{
			selection = menu();
			if (selection == 1)
			{
				displayEmployee(conn, employee);
			}
			else if (selection == 2)
			{
				displayAllEmployees(conn);
			}
			else if (selection == 3) {
				Employee temp;
				getEmployee(&temp);
				insertEmployee(conn, temp);
			}
			else if (selection == 4) {
				employeeNum = getInt("Enter Employee Number: ");
				updateEmployee(conn, employeeNum);
			}
			else if (selection == 5) {
				employeeNum = getInt("Enter Employee Number: ");
				deleteEmployee(conn, employeeNum);
			}
			else
			{
				isQuit = true;
			}

		} while (isQuit == false);

		//  Oracle connection and environment closed
		env->terminateConnection(conn);
		Environment::terminateEnvironment(env);
	}
	catch (SQLException& sqlExcp)
	{
		//  Oracle error code and message thrown if exception caught
		cout << sqlExcp.getErrorCode() << ": " << sqlExcp.getMessage();
	}
	return 0;
}
int menu(void)
{
	string choice;
	int value = -1;
	cout << "********************* HR Menu *********************" << endl;
	cout << "1) Find Employee" << endl;
	cout << "2) Employees Report" << endl;
	cout << "3) Add Employee" << endl;
	cout << "4) Update Employee" << endl;
	cout << "5) Remove Employee" << endl;
	cout << "0) Exit" << endl;
	cout << "Please enter an option: ";
	do
	{
		cin >> choice;
		if (choice == "1")
		{
			value = 1;
		}
		else if (choice == "2")
		{
			value = 2;
		}
		else if (choice == "3")
		{
			value = 3;
		}
		else if (choice == "4")
		{
			value = 4;
		}
		else if (choice == "5")
		{
			value = 5;
		}
		else if (choice == "0")
		{
			value = 0;
		}
		else
		{
			cout << "Please enter a valid option from the list: ";
			value = -1;
		}
		cin.clear();
		cin.ignore(2000, '\n');
	} while (value == -1);
	return value;
}
int findEmployee(Connection* conn, int employeeNumber, struct Employee* emp)
{
	int result = 0;
	string Value;
	//  Statement and ResultSet objects to be iterated through later with the next() function
	Statement* stmt = conn->createStatement();
	ResultSet* rs = stmt->executeQuery("SELECT e.employeenumber, e.lastname, e.firstname, e.email, o.phone,e.officecode, e.extension, em.firstname || ' ' || em.lastname,e.jobtitle, o.city FROM employees e LEFT JOIN employees em ON e.reportsto =em.employeenumber JOIN offices o ON e.officecode = o.officecode WHERE e.employeenumber = " + to_string(employeeNumber) + " ORDER BY e.employeenumber");
	//  while loop to access one and only one employee's information and assign it over to the struct emp members
	while (rs->next())
	{
		//  variables needed by the columns from the SQL query result
		emp->employeeNumber = rs->getInt(1);
		sprintf_s(emp->lastName, rs->getString(2).c_str());
		sprintf_s(emp->firstName, rs->getString(3).c_str());
		sprintf_s(emp->email, rs->getString(4).c_str());
		sprintf_s(emp->phone, rs->getString(5).c_str());
		sprintf_s(emp->extension, rs->getString(6).c_str());
		sprintf_s(emp->officecode, rs->getString(7).c_str());
		sprintf_s(emp->reportsTo, rs->getString(7).c_str());
		sprintf_s(emp->jobTitle, rs->getString(8).c_str());
		sprintf_s(emp->city, rs->getString(9).c_str());
		result = 1;
	}
	// Terminate connection
	conn->terminateStatement(stmt);
	return result;
}
void displayEmployee(Connection* conn, struct Employee emp)
{
	int Value;
	bool validFlag = false;
	// Get user input for employee number and utilize while loop to reject invalid entries.
	cout << "Enter employee number: ";
	while (validFlag == false)
	{
		if (!(cin >> Value))
		{
			cout << "Only digits allowed. Enter employee number: " <<
				endl;
		}
		else
		{
			validFlag = true;
		}
		// Clears input buffer
		cin.clear();
		cin.ignore(2000, '\n');
	}
	cout << endl;
	// Call the findEmployee to evaluate if the employee exists in the query and recieve 1 or 0
	if (findEmployee(conn, Value, &emp) > 0)
	{
		// Display employee information
		cout << "employeeNumber = " << emp.employeeNumber << endl
			<< "firstname = " << emp.firstName << endl
			<< "lastname = " << emp.lastName << endl
			<< "email = " << emp.email << endl
			<< "phone = " << emp.phone << endl
			<< "extension = " << emp.extension << endl
			<< "reportsTo = " << emp.reportsTo << endl
			<< "jobTitle = " << emp.jobTitle << endl
			<< "city = " << emp.city << endl;
	}
	else
	{
		// Display error when employee not found
		cout << "Employee " << Value << " does not exist" << endl;
	}
	cout << endl;
	cout.flush();
}
void displayAllEmployees(Connection* conn)
{
	// Create Statement and ResultSet objects to be iterated through later with the next() function
	Statement* stmt = conn->createStatement();
	ResultSet* rs = stmt->executeQuery("SELECT e.employeenumber, e.firstname || ' ' || e.lastname, e.email, o.phone, e.extension, em.firstname || ' ' ||em.lastname FROM employees e LEFT JOIN employees em ON e.reportsto =em.employeenumber JOIN offices o ON e.officecode = o.officecode ORDER BY e.employeenumber");
	// Print table header
	cout << endl << "E	Employee Name 	    Email 				Phone 		    Ext	        Manager" << endl << endl << "---------------------------------------------------------------------------------------------------------------" << endl;
	// Get values from ResultSet's rows, as long as there's a next row, with next() function
	while (rs->next())
	{
		// Create variables needed by the columns from the SQL query result
		int employeeNum = rs->getInt(1);
		string employeeName = rs->getString(2);
		string email = rs->getString(3);
		string phone = rs->getString(4);
		string ext = rs->getString(5);
		string manager = rs->getString(6);
		// Print each RecordSet's row values in a line
		cout << endl
			<< setw(8) << left << employeeNum
			<< setw(20) << left << employeeName
			<< setw(36) << left << email
			<< setw(20) << left << phone
			<< setw(12) << left << ext
			<< setw(24) << left << manager
			<< endl;
	}
	cout << endl;
	cout.flush();
	conn->terminateStatement(stmt);
}
int getInt(const char* prompt)
{
	int val;
	int flag = 0;
	if (prompt)
		cout << prompt;
	do {
		cin >> val;
		if (cin.fail())//when invalid character entered instead of an int
		{
			cout << "Only integers are allowed, try again: ";
			cin.clear();
			while (cin.get() != '\n');
		}
		else if (cin.get() != '\n')//when more than one employeeNmubers are entered 
		{
			cout << "Only one employeeNumber is allowed, try again: ";
			while (cin.get() != '\n');
		}
		else flag = 1;

	} while (flag == 0);
	return val;
}
void getEmployee(Employee* emp)
{
	char office[10] = "1";
	char report[5] = "1002";
	cout << endl << "-------------- New Employee Information -------------" << endl;
	cout << "Employee Number: ";
	cin >> emp->employeeNumber;
	cout << "Last Name: ";
	cin >> emp->lastName;
	cout << "First Name: ";
	cin >> emp->firstName;
	cout << "Extenstion: ";
	cin >> emp->extension;
	cout << "Email: ";
	cin >> emp->email;
	cout << "Office Code: 1" << endl;
	strncpy(emp->officecode, office, 9);
	cout << "Manager ID: 1002" << endl;
	strncpy(emp->reportsTo, report, 4);
	cin.ignore();
	cout << "Job Title: ";
	cin.getline(emp->jobTitle, 50);

	cout << endl;
}
void insertEmployee(Connection* conn, struct Employee emp)
{
	if (findEmployee(conn, emp.employeeNumber, &emp))//calling findeEmployee to check if the entered employeeNumber already exists
	{
		cout << "An employee with the same employee number exists." << endl << endl;

	}
	else
	{
		Statement* stmt = conn->createStatement();
		stmt->setSQL("INSERT INTO employees(employeenumber, lastname, firstname, extension, email, officecode, reportsto, jobtitle) VALUES(:1, :2, :3, :4, :5, :6, :7, :8)");
		stmt->setInt(1, emp.employeeNumber);
		stmt->setString(2, emp.lastName);
		stmt->setString(3, emp.firstName);
		stmt->setString(4, emp.extension);
		stmt->setString(5, emp.email);
		stmt->setString(6, emp.officecode);
		stmt->setString(7, emp.reportsTo);
		stmt->setString(8, emp.jobTitle);
		stmt->executeUpdate();
		cout << "The new employee is added successfully." << endl << endl;
		conn->commit();
		conn->terminateStatement(stmt);
	}
	cout.flush();
}


void deleteEmployee(Connection* conn, int employeeNumber)
{
	Employee emp;
	if (!findEmployee(conn, employeeNumber, &emp))//callinf FindEmployee to check if the enetered employeeNmuber exists or not
	{
		cout << "The employee with ID " << employeeNumber << " does not exist." << endl;
	}
	else
	{
		Statement* stmt = conn->createStatement();
		stmt->setSQL("DELETE FROM employees WHERE employeenumber = :1");
		stmt->setInt(1, employeeNumber);
		stmt->executeUpdate();
		cout << "The employee with ID " << employeeNumber << " is deleted successfully." << endl << endl;
		conn->commit();
		conn->terminateStatement(stmt);
	}
}

void updateEmployee(Connection* conn, int employeeNumber)
{
	Employee emp;

	if (findEmployee(conn, employeeNumber, &emp)) {
		cout << "Last Name: " << emp.lastName << endl;
		cout << "First Name: " << emp.firstName << endl;
		cout << "Extension: ";

		cin >> emp.extension;

		Statement* stmt = conn->createStatement();

		stmt->setSQL("UPDATE employees SET EXTENSION = :1 where employeenumber = :2");


		stmt->setString(1, emp.extension);

		stmt->setInt(2, emp.employeeNumber);

		stmt->executeUpdate();


		cout << "The employee's extension is updated successfully." << endl << endl;
		conn->commit();
		conn->terminateStatement(stmt);
	}
	else cout << "The employee with ID " << employeeNumber << " does not exist." << endl << endl;
}

