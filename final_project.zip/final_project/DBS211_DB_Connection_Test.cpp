/*
DBS211 - Milestone 1
Section: ZEE

*/
#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <iomanip>
#include <occi.h>
#include <cctype>

using oracle::occi::Environment;
using oracle::occi::Connection;

using namespace oracle::occi;
using namespace std;

struct Employee {
	int employeeNumber;
	char lastName[50];
	char firstName[50];
	char email[100];
	char officeCode[10];
	char extension[10];
	char reportsTo[100];
	char jobTitle[50];

};


int findEmployee(Connection* conn, int employeeNumber, struct Employee* emp);

void displayEmployee(Connection* conn, struct Employee emp);

int main(void)
{

	Environment* env = nullptr;
	Connection* conn = nullptr;

	string usr = "dbs211_221k13";
	string pass = "12694242";
	string srv = "myoracle12c.senecacollege.ca:1521/oracle12c";

	try
	{

		env = Environment::createEnvironment(Environment::DEFAULT);
		conn = env->createConnection(usr, pass, srv);

		cout << "Connection is Successful!" << endl;
		cout << "Group Number: 2" << endl << "Member Names:" << endl << "1. Disha Rawat" << endl << "2. Harpreet Singh" << endl << "3. Pavneet Kaur" << endl << "4. Rahul Raj" << endl << "5. Tanish" << endl;
		Employee empObj = {};
		displayEmployee(conn, empObj);


		env->terminateConnection(conn);
		Environment::terminateEnvironment(env);
	}
	catch (SQLException& sqlExcp)
	{

		cout << sqlExcp.getErrorCode() << ": " << sqlExcp.getMessage();
	}
	return 0;
}

int findEmployee(Connection* conn, int employeeNumber, struct Employee* emp)
{
	int result = 0;
	string Value;

	Statement* stmt = conn->createStatement();
	ResultSet* rs = stmt->executeQuery("SELECT employeeNumber, lastName, firstName, extension, email,officeCode, reportsto, jobTitle FROM employees  WHERE employeenumber = " + to_string(employeeNumber) + " ORDER BY employeenumber");

	while (rs->next())
	{

		emp->employeeNumber = rs->getInt(1);
		sprintf_s(emp->lastName, rs->getString(2).c_str());
		sprintf_s(emp->firstName, rs->getString(3).c_str());
		sprintf_s(emp->extension, rs->getString(4).c_str());
		sprintf_s(emp->email, rs->getString(5).c_str());
		sprintf_s(emp->officeCode, rs->getString(6).c_str());
		sprintf_s(emp->reportsTo, rs->getString(7).c_str());
		sprintf_s(emp->jobTitle, rs->getString(8).c_str());

		result = 1;
	}

	conn->terminateStatement(stmt);
	return result;
}
void displayEmployee(Connection* conn, struct Employee emp)
{
	int Value;
	bool valid = false;

	cout << "Enter employee number: ";
	while (valid == false)
	{
		if (!(cin >> Value))
		{
			cout << "Only digits allowed. Enter employee number: " <<
				endl;
		}
		else
		{
			valid = true;
		}

		cin.clear();
		cin.ignore(2000, '\n');
	}
	cout << endl;

	if (findEmployee(conn, Value, &emp) > 0)
	{
		cout << "EmployeeNumber LastName  FirstName Extension Email                          OfficeCode   Reportsto    JobTitle" << endl;
		cout << setw(15) << left << emp.employeeNumber << setw(10) << left << emp.lastName << setw(10) << left << emp.firstName << setw(10) << left << emp.extension << setw(35) << left << emp.email << setw(11) << left << emp.officeCode << setw(9) << left << emp.reportsTo << setw(20) << left << emp.jobTitle << endl;

	}
	else
	{
		
		cout << "Employee " << Value << " does not exist" << endl;
	}
	cout << endl;
	cout.flush();
}



